﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZP3CS_cv03
{
    class FrontaException : Exception{

    }


    class Fronta
    {
        Prvek prvni, posledni;

        public void Pridej(int hodnota)
        {
            Prvek novy = new Prvek();
            novy.value = hodnota;
            if (posledni != null) posledni.next = novy; else prvni = novy;
           
            //novy.next = posledni;
            posledni = novy;           

        }
        public int Odeber()
        {
            Prvek p = prvni;
            if (prvni == null) throw new FrontaException();
            prvni = prvni.next;
            return p.value;            
        }
        public bool JePrazdna() { return prvni == null; }

        

    }
}
