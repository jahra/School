﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZP3CS_cv03
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {
                int a = 0;
                int b = a;
            }
            catch (Exception e)
            {
                Console.WriteLine("Zachycena vyjimka: " + e.Message);
                throw;
            }
            Console.WriteLine("jedeme dal");


            Fronta f = new Fronta();
            f.Pridej(1);
            f.Pridej(2);
            f.Pridej(3);
            f.Pridej(4);

            while (!f.JePrazdna())
            {
                Console.WriteLine(f.Odeber);
            }

        }
    }
}
