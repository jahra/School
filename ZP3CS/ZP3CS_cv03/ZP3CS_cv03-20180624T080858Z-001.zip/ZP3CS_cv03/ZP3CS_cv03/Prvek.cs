﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZP3CS_cv03
{
    class Prvek
    {
        public int value;
        public Prvek next;

    }
}
